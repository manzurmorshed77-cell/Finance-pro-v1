# My Finance Pro v2
Professional offline income & expense tracker for Android.
Features: dashboard, income/expense, categories, accounts, monthly summary, search, edit/delete, CSV export, backup/share.
Open in Android Studio and Build > Build APK(s).
