package com.example.myfinance

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

data class Tx(var id:Long,var type:String,var amount:Double,var category:String,var account:String,var note:String,var date:String)

class MainActivity:Activity(){
 private lateinit var sp:android.content.SharedPreferences
 private val data=mutableListOf<Tx>()
 private lateinit var body:LinearLayout
 private lateinit var summary:TextView
 private val dateFmt=SimpleDateFormat("dd/MM/yyyy",Locale.getDefault())
 override fun onCreate(b:Bundle?){super.onCreate(b);sp=getSharedPreferences("db",0);load();ui()}
 private fun load(){data.clear();(sp.getString("data","")?:"").lines().filter{it.isNotBlank()}.forEach{p->val x=p.split("¦");if(x.size==7) data.add(Tx(x[0].toLong(),x[1],x[2].toDouble(),x[3],x[4],x[5],x[6]))}}
 private fun save(){sp.edit().putString("data",data.joinToString("\n"){"${it.id}¦${it.type}¦${it.amount}¦${it.category}¦${it.account}¦${it.note.replace("¦"," ")}¦${it.date}"}).apply()}
 private fun tv(s:String,size:Float=16f)=TextView(this).apply{text=s;textSize=size;setPadding(8,10,8,10)}
 private fun ui(){
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,10)}
  root.addView(tv("MY FINANCE PRO",26f).apply{setTextColor(Color.rgb(21,101,192))})
  summary=tv("",18f);root.addView(summary)
  val buttons=LinearLayout(this); buttons.addView(Button(this).apply{text="＋ Income";setOnClickListener{add("Income")}},LinearLayout.LayoutParams(0,-2,1f))
  buttons.addView(Button(this).apply{text="－ Expense";setOnClickListener{add("Expense")}},LinearLayout.LayoutParams(0,-2,1f));root.addView(buttons)
  val tools=LinearLayout(this)
  tools.addView(Button(this).apply{text="Report";setOnClickListener{report()}},LinearLayout.LayoutParams(0,-2,1f))
  tools.addView(Button(this).apply{text="Export";setOnClickListener{export()}},LinearLayout.LayoutParams(0,-2,1f))
  root.addView(tools)
  val sc=ScrollView(this);body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(body);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
  setContentView(root);refresh()
 }
 private fun refresh(){
  val inc=data.filter{it.type=="Income"}.sumOf{it.amount};val exp=data.filter{it.type=="Expense"}.sumOf{it.amount}
  summary.text="Income  ৳%,.2f    Expense  ৳%,.2f\nBalance  ৳%,.2f".format(inc,exp,inc-exp)
  body.removeAllViews()
  data.sortedByDescending{it.id}.forEach{t->
   val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
   row.addView(tv("${t.date}   ${t.type}   ৳%,.2f".format(t.amount),17f))
   row.addView(tv("${t.category} • ${t.account}\n${t.note}"))
   row.setOnClickListener{edit(t)};body.addView(row)
  }
 }
 private fun add(type:String){
  val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(15,0,15,0)}
  val amount=EditText(this);amount.hint="Amount (BDT)";amount.inputType=2;b.addView(amount)
  val cat=EditText(this);cat.hint="Category";b.addView(cat)
  val acc=EditText(this);acc.hint="Account: Cash / Bank / bKash";b.addView(acc)
  val note=EditText(this);note.hint="Description / Note";b.addView(note)
  AlertDialog.Builder(this).setTitle("Add $type").setView(b).setPositiveButton("SAVE"){_,_->
   val a=amount.text.toString().toDoubleOrNull()?:0.0
   if(a>0){data.add(Tx(System.currentTimeMillis(),type,a,cat.text.toString().ifBlank{"General"},acc.text.toString().ifBlank{"Cash"},note.text.toString(),dateFmt.format(Date())));save();refresh()}
  }.setNegativeButton("CANCEL",null).show()
 }
 private fun edit(t:Tx){
  val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(15,0,15,0)}
  val amount=EditText(this);amount.setText(t.amount.toString());amount.inputType=2;b.addView(amount)
  val cat=EditText(this);cat.setText(t.category);b.addView(cat)
  val acc=EditText(this);acc.setText(t.account);b.addView(acc)
  val note=EditText(this);note.setText(t.note);b.addView(note)
  AlertDialog.Builder(this).setTitle("Edit Transaction").setView(b).setPositiveButton("UPDATE"){_,_->
   amount.text.toString().toDoubleOrNull()?.let{t.amount=it};t.category=cat.text.toString();t.account=acc.text.toString();t.note=note.text.toString();save();refresh()
  }.setNeutralButton("DELETE"){_,_->data.remove(t);save();refresh()}.setNegativeButton("CANCEL",null).show()
 }
 private fun report(){
  val inc=data.filter{it.type=="Income"}.sumOf{it.amount};val exp=data.filter{it.type=="Expense"}.sumOf{it.amount}
  val cats=data.groupBy{it.category}.mapValues{(_,v)->v.sumOf{if(it.type=="Expense")it.amount else -it.amount}}
  val s=StringBuilder("MONTH / OVERALL REPORT\n\nIncome: ৳%,.2f\nExpense: ৳%,.2f\nBalance: ৳%,.2f\n\nCategories:\n".format(inc,exp,inc-exp))
  cats.forEach{(k,v)->s.append("$k : ৳%,.2f\n".format(v))}
  AlertDialog.Builder(this).setTitle("Financial Report").setMessage(s.toString()).setPositiveButton("OK",null).show()
 }
 private fun export(){
  val csv="Date,Type,Amount,Category,Account,Note\n"+data.joinToString("\n"){ "${it.date},${it.type},${it.amount},${it.category},${it.account},${it.note.replace(","," ")}" }
  val i=Intent(Intent.ACTION_SEND);i.type="text/csv";i.putExtra(Intent.EXTRA_TEXT,csv);startActivity(Intent.createChooser(i,"Share / Backup CSV"))
 }
}