plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.example.myfinance"; compileSdk=35
 defaultConfig { applicationId="com.example.myfinance"; minSdk=24; targetSdk=35; versionCode=2; versionName="2.0" }
}
